
baseDir=$(dirname "$0")
iPadTestsDir="$baseDir/tests-ipad"
iPhoneTestsDir="$baseDir/tests-iphone"

build_dir=$1

case $build_dir in
     /*) absolute=1 ;;
     *) build_dir="$(pwd)/$build_dir" ;;
esac

tmpDir="$baseDir/tmp"
rm -rf "$tmpDir"
mkdir "$tmpDir"

info_plist="$build_dir/iCanvas.app/Info.plist"

cp "$info_plist" "$info_plist.bak"

runTest() {
    test_script=$1
    
    token_file=$(echo -n "$test" | sed "s/.js/.txt/")
    if [[ -e $token_file ]]; then
        access_token=$(cat "$token_file")
        echo "Using specified token: <$access_token>"
    else
        access_token="5sEDPyspw3uNJCmZ23CSrLMObmOzgQUky68sxVNCwph2iTlCm71RLqfdMTBjHFhb"
        echo "Using default token for iOS Teacher"
    fi
    echo "Killing existing 'instruments' processes"
    killall -9 instruments
    instruments \
    -D "$tmpDir/theTrace.trace" \
    -t "$(xcode-select -print-path)/../Applications/Instruments.app/Contents/PlugIns/AutomationInstrument.bundle/Contents/Resources/Automation.tracetemplate" \
    "$build_dir/iCanvas.app" \
    -e UIARESULTSPATH "$tmpDir" \
    -e CKAccessToken "$access_token" \
    -e UIASCRIPT $test
    
    rm -r "$tmpDir/theTrace.trace"
}

set +e

/usr/libexec/PlistBuddy -c "Delete :UIDeviceFamily:1" $info_plist

# Force execution on iPhone
/usr/libexec/PlistBuddy -c "Set :UIDeviceFamily:0 1" $info_plist
if [ "$(ls $iPhoneTestsDir)" ]; then
    for test in $iPhoneTestsDir/*.js
    do
        echo "Running iPhone test: $test"
        runTest "$test"
    done
fi

# Force execution on iPad
/usr/libexec/PlistBuddy -c "Set :UIDeviceFamily:0 2" $info_plist
if [ "$(ls $iPadTestsDir)" ]; then
    for test in $iPadTestsDir/*.js
    do
        echo "Running iPad test: $test"
        runTest "$test"
    done
fi

set -e

# Put back the info.plist
rm "$info_plist"
cp "$info_plist.bak" "$info_plist"

set +e
find . -name "Automation Results.plist" -print0 | xargs -0 $baseDir/automation-results
retVal=$?
set -e

rm -rf "$tmpDir"

echo "UIAutomation result: $retVal"
exit $retVal