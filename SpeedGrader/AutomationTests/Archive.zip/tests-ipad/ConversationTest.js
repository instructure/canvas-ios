#import "../tuneup/tuneup.js"

test("Conversation on iPad is correct", function (target, app) {
	 
	 // Navigate to Conversations and select the test conversation
	 target.frontMostApp().toolbar().buttons()["Conversations"].tap();
	 // Verify at least the three expected conversations are showing...
	 var conversationsCount = target.frontMostApp().mainWindow().tableViews()["Empty list"].cells().length;
	 assertTrue(conversationsCount == 3); // There should be three conversations.
	 target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()["iOS Observer, kind of"].tap();
	 
	 // Check showing/hiding keyboard
	 assertNull(target.frontMostApp().keyboard());
	 target.frontMostApp().mainWindow().textFields()[0].tap();
	 assertNotNull(target.frontMostApp().keyboard());
	 target.frontMostApp().keyboard().buttons()["Hide keyboard"].tap();
	 target.delay(1);
	 assertNull(target.frontMostApp().keyboard());
	 
	 // Test a link to an image
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].staticTexts()["No"].scrollToVisible();
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].links()["delete-cookies-monster.jpg"].tap();
	 assertNotNull(target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].images().firstWithPredicate("url BEGINSWITH 'https://s3.amazonaws.com/instructure-uploads/account_86906/attachments/4622955/delete-cookies-monster.jpg'"));
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].dragInsideWithOptions({startOffset:{x:0.24, y:0.17}, endOffset:{x:0.24, y:0.55}, duration:1.1});
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].dragInsideWithOptions({startOffset:{x:0.23, y:0.83}, endOffset:{x:0.21, y:0.57}});
	 target.frontMostApp().toolbar().buttons()["Done"].tap();
	 
	 // Test link to a movie
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].links()["Movie on 1-13-12 at 12.49 PM.mov"].tap();
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].buttons()["inline play"].tap();
	 target.frontMostApp().toolbar().buttons()["Done"].tap();
	 
	 // Test creating a new message
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].tapWithOptions({tapOffset:{x:0.44, y:0.35}});
	 target.frontMostApp().mainWindow().textFields()[0].tap();
	 target.frontMostApp().mainWindow().buttons()["compose unselected"].tap();
	 target.frontMostApp().mainWindow().textFields()[1].tap();
	 
	 // Test searching for a recipient
	 // Verify you can find the iOS TA
	 target.frontMostApp().keyboard().typeString("ios ta");
	 assertNotNull(target.frontMostApp().mainWindow().popover().tableViews()["Empty list"].cells()["iOS TA"]);
	 // Correct and find the treacher
	 target.frontMostApp().keyboard().buttons()["Delete"].tap();
	 target.frontMostApp().keyboard().typeString("e");
	 target.frontMostApp().mainWindow().popover().tableViews()["Empty list"].cells()["iOS Teacher"].tap();
	 target.frontMostApp().mainWindow().textFields()[2].tap();
 	 target.frontMostApp().mainWindow().textFields()[2].logElementTree();
	 
	 // Finished
	 target.frontMostApp().mainWindow().buttons()["close button"].tap();
});