#import "../tuneup/tuneup.js"

test("User information is correct", function (target, app) {
	 
	 // Wait for the asynchronous call to populate user information
	 target.delay(1);
	 
	 app.toolbar().buttons()["toolbar profile button"].tap();
	 
	 assertNotNull(app.mainWindow().tableViews()[2].cells()["Name, iOS Teacher"], "Couldn't find teacher name");
	 
	 assertNotNull(app.mainWindow().tableViews()[2].cells()["Email, eng-devices+teacher@instructure.com"], "Couldn't find teacher email");
	 assertNotNull(app.mainWindow().tableViews()[2].cells()["Login ID, eng-devices+teacher@instructure.com"], "Couldn't find teacher Login ID");
	 assertNotNull(app.mainWindow().tableViews()[2].cells()["Domain, iosautomation.instructure.com"], "Couldn't find login domain");

	 app.navigationBar().rightButton().tap();
});