#import "../../Pods/tuneup_js/assertions.js"
#import "../../Pods/tuneup_js/lang-ext.js"


extend(UIAApplication.prototype, {
  
  /**
   * A shortcut for getting the current view controller's title from the
   * navigation bar. If there is no navigation bar, this method returns null
   */
  studentLogin: function () {	
	 this.login("mobileqa.instructure.com", "s1", "instruct");
	 this.confirmLogin();
  },
  
  /**
   * A shortcut for getting the current view controller's title from the
   * navigation bar. If there is no navigation bar, this method returns null
   */
  teacherLogin: function () {	
	 this.login("mobileqa.instructure.com", "t1", "instruct");
 	 this.confirmLogin();
  },
  
  /**
   * A shortcut for getting the current view controller's title from the
   * navigation bar. If there is no navigation bar, this method returns null
   */
  taLogin: function () {	
	 this.login("mobileqa.instructure.com", "ta1", "instruct");
  	 this.confirmLogin();
  },

  /**
   * A shortcut for getting the current view controller's title from the
   * navigation bar. If there is no navigation bar, this method returns null
   */
  login: function (domainName, username, password) {
  	 UIALogger.logMessage("Login: " + domainName + " : " + username + " : " + password);
  
	 var window = this.mainWindow();
	 var target = UIATarget.localTarget();
	
	 // domain information
	 window.textFields()["Enter Domain Text Field"].setValue(domainName);
	 target.delay(1);
	 this.keyboard().buttons()["Go"].tap();
	 
	 // delay 2 seconds for web request to return.
	 target.delay(2);
	 var webView = window.scrollViews()[0].webViews()[0];
	 
	 // username field
	 var textFields = webView.textFields();
	 textFields[0].tap();		
 	 target.delay(1);
	 this.keyboard().typeString(username);

	 // password field
	 var secureTextFields = webView.secureTextFields();
	 secureTextFields[0].tap();	
	 target.delay(1);	 
	 this.keyboard().typeString(password);
  },
  
  /**
   * A shortcut for getting the current view controller's title from the
   * navigation bar. If there is no navigation bar, this method returns null
   */
  confirmLogin: function () {
 	 var window = this.mainWindow();
 	 var webView = window.scrollViews()[0].webViews()[0];
	  
	  // login
	  target.delay(1);	 
	  webView.buttons()["Login"].tap();
 
	  // confirm
	  target.delay(1);	 
	  webView.buttons()["Log In"].tap();
  },
  
  /**
   * A shortcut to logout of the current application on the iPhone
   */
  logout: function () {
  	this.tabBar().buttons()["Profile"].tap();
	this.mainWindow().buttons()["Logout"].tap();
	this.actionSheet().buttons()["Logout"].tap();
	
	var target = UIATarget.localTarget();
	target.delay(1);
  }
});