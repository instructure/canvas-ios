#import "../../Pods/tuneup_js/tuneup.js"
#import "../ui-screen-shooter/capture.js"
#import "canvas-ext.js"

test("Login page layout correct", function(target, app) {
	 captureLocalizedScreenshot("Login_Layout");
});

test("\"Connect To Canvas Network\" pushes to \"learn.canvas.net\"", function(target, app) {
	
	 var window = app.mainWindow();
	 
	 target.delay(1);
	 window.buttons()["Canvas Network Button"].tap();
	 
	 // delay 3 to wait for screen to load
	 target.delay(3);
	 var navBar = window.navigationBar();
	 var domainName = "learn.canvas.net";
	 var navBarLabel = navBar.staticTexts()[0];
	 assertEquals(navBarLabel.name(), domainName);
	 
	 // capture learn.canvas.net screenshot
	 captureLocalizedScreenshot("Canvas_Network_Login");
	 
	 // cancel login
	 navBar.buttons()["Cancel"].tap();
	 
	 // back out delay
	 target.delay(1);
});

test("Login failure with incorrect domain", function(target, app) {
	 
	 var window = app.mainWindow();
	 var navBar = window.navigationBar();
	
	 // domain information
	 window.textFields()["Enter Domain Text Field"].setValue("fake.instructure.com");
	 target.delay(1);
	 app.keyboard().buttons()["Go"].tap();
	 
	 // delay 3 seconds for web request to return.
	 target.delay(3);
	 captureLocalizedScreenshot("404_Error")
	 	
	 // cancel login
	 var navBar = window.navigationBar();
	 navBar.buttons()["Cancel"].tap();
	 
	 // back out delay
	 target.delay(1);
});

test("Login failure with incorrect username", function(target, app) {
	 
	 var window = app.mainWindow();
	 
	 app.login("mobileqa.instructure.com", "s_fake", "instruct");
	 
	 captureLocalizedScreenshot("Login_Failed_User")
	 	
	 // cancel login
	 var navBar = window.navigationBar();
	 navBar.buttons()["Cancel"].tap();
	 
	 // back out delay
	 target.delay(1);
});

test("Login failure with incorrect password", function(target, app) {
	 var window = app.mainWindow();
	 
	 app.login("mobileqa.instructure.com", "s1", "pass_fake");
	 
	 captureLocalizedScreenshot("Login_Failed_Pass")
	 	
	 // cancel login
	 var navBar = window.navigationBar();
	 navBar.buttons()["Cancel"].tap();
	 
	 // back out delay
	 target.delay(1);
});

test("\"instructure.com\" appended to typed url", function(target, app) {
	 var window = app.mainWindow();
	 
	 target.delay(1);
	 // domain information
	 var domainName = "mobileqa";
	 window.textFields()["Enter Domain Text Field"].setValue(domainName);
	 target.delay(1);
	 app.keyboard().buttons()["Go"].tap();
	 
	 // delay 3 to wait for screen to load
	 target.delay(3);
	 var navBar = window.navigationBar();
	 var navBarLabel = navBar.staticTexts()[0];
	 assertEquals(navBarLabel.name(), "mobileqa.instructure.com");
	 
	 // capture learn.canvas.net screenshot
	 captureLocalizedScreenshot("INSTRUCTURE_APPEND");
	 
	 // cancel login
	 navBar.buttons()["Cancel"].tap();
	 
	 // back out delay
	 target.delay(1);
});

test("Typing full URL does not append \"instructure.com\"", function(target, app) {
	 var window = app.mainWindow();
	 
	 target.delay(1);
	 // domain information
	 var domainName = "mobileqa.instructure.com";
	 window.textFields()["Enter Domain Text Field"].setValue(domainName);
	 target.delay(1);
	 app.keyboard().buttons()["Go"].tap();
	 
	 // delay 3 to wait for screen to load
	 target.delay(3);
	 var navBar = window.navigationBar();
	 var navBarLabel = navBar.staticTexts()[0];
	 assertEquals(navBarLabel.name(), domainName);
	 
	 // capture learn.canvas.net screenshot
	 captureLocalizedScreenshot("FULL_URL");
	 
	 // cancel login
	 navBar.buttons()["Cancel"].tap();
	 
	 // back out delay
	 target.delay(1);
});

test("Canvas Login Page reduces for login (mobile sized)", function(target, app) {
	 var window = app.mainWindow();
	 
	 target.delay(1);
	 
	 // enter domain
	 var domainName = "mobileqa.instructure.com";
	 window.textFields()["Enter Domain Text Field"].setValue(domainName);
	 target.delay(1);
	 app.keyboard().buttons()["Go"].tap();
	 
	 // delay 3 to wait for screen to load
	 target.delay(3);
	 
	 // capture screenshot
	 captureLocalizedScreenshot("CORRECT_LOGIN_WEBVIEW");
	 
	 // cancel login
	 var navBar = window.navigationBar();
	 navBar.buttons()["Cancel"].tap();
	 
	 // back out delay
	 target.delay(1);
});

test("Canvas Login Page reduces for login (mobile sized)", function(target, app) {
	 var window = app.mainWindow();
	 var target = UIATarget.localTarget();
	 
	 target.delay(1);
	 
	 // enter domain
	 var domainName = "mobileqa.instructure.com";
	 window.textFields()["Enter Domain Text Field"].setValue(domainName);
	 target.delay(1);
	 app.keyboard().buttons()["Go"].tap();
	 
	 // delay 3 to wait for screen to load
	 target.delay(3);
	 
	 // capture screenshot
	 captureLocalizedScreenshot("CORRECT_LOGIN_WEBVIEW");
	 
	 // cancel login
	 var navBar = window.navigationBar();
	 navBar.buttons()["Cancel"].tap();
	 
	 // back out delay
	 target.delay(1);
});

test("I don't know my password functions properly", function(target, app) {
	 
	 var window = app.mainWindow();
	 
	 // domain information
	 var domainName = "mobileqa.instructure.com";
	 window.textFields()["Enter Domain Text Field"].setValue(domainName);
	 target.delay(1);
	 app.keyboard().buttons()["Go"].tap();
	 
	 // delay 2 seconds for web request
	 target.delay(2);
	 var passwordResetButton = window.scrollViews()[0].webViews()[0].staticTexts()["I don't know my password"];
	 passwordResetButton.tap();
	
 	 target.delay(1);
	 captureLocalizedScreenshot("Forgot_Password");
	 
	 // enter text and press enter
	 var webView = window.scrollViews()[0].webViews()[0];
	 
	 // username field
	 var textFields = webView.textFields();
	 textFields[0].tap();		
 	 target.delay(1);
	 app.keyboard().typeString("s1@soccerstorm.com");
	 
 	 target.delay(1);
	 window.scrollViews()[0].webViews()[0].buttons()["Request Password"].tap();	 

	 // delay 4 seconds for web request
	 target.delay(3);
	 passwordResetButton.tap();
	 
 	 target.delay(1);
	 window.scrollViews()[0].webViews()[0].staticTexts()["Back to Login"].tap();
	 
	 
	 // cancel login
	 var navBar = window.navigationBar();
	 navBar.buttons()["Cancel"].tap();
	 
	 // back out delay
	 target.delay(1);
	 
});

test("Canvas login page cancel button works", function(target, app) {
 	var window = app.mainWindow();
 
 	target.delay(1);
 
 	// enter domain
 	var domainName = "mobileqa.instructure.com";
 	window.textFields()["Enter Domain Text Field"].setValue(domainName);
 	target.delay(1);
 	app.keyboard().buttons()["Go"].tap();
 
 	// delay 3 to wait for screen to load
 	target.delay(3);
 
 	// cancel login
 	var navBar = window.navigationBar();
 	navBar.buttons()["Cancel"].tap();
 	
 	// back out delay
 	target.delay(1);
});

test("Canvas login page has correct user info displayed", function(target, app) {
	 app.login("mobileqa.instructure.com", "s1", "instruct");
	 
	 var window = app.mainWindow();
 	 var webView = window.scrollViews()[0].webViews()[0];
	  
	 // login
	 target.delay(1);	 
	 webView.buttons()["Login"].tap();
	 
	 target.delay(3);
	 captureLocalizedScreenshot("Canvas_Login_Info");
	 
	 // cancel login
 	var navBar = window.navigationBar();
 	navBar.buttons()["Cancel"].tap();
 	
 	// back out delay
 	target.delay(1);
	 
});

test("Login success with correct credentials", function(target, app) {
	 
	 app.login("mobileqa.instructure.com", "s1", "instruct");
	 app.confirmLogin();
	 app.logout();
});

test("Previous successfully logged in URL is saved", function(target, app) {

	 var window = app.mainWindow();
	 
	 var previousDomainName = "mobileqa.instructure.com";
	 
	 window.textFields()["Enter Domain Text Field"].tap();
	 target.delay(1);
	 window.tableViews()["Empty list"].cells()[previousDomainName].tap();
	 
	 // delay 2 seconds for web request to return.
	 target.delay(2);
	 var webView = window.scrollViews()[0].webViews()[0];
	 
	 // username field
	 var textFields = webView.textFields();
	 textFields[0].tap();		
 	 target.delay(1);
	 app.keyboard().typeString("s1");

	 // password field
	 var secureTextFields = webView.secureTextFields();
	 secureTextFields[0].tap();	
	 target.delay(1);	 
	 app.keyboard().typeString("instruct");
	 
	 target.delay(2);	 
	 app.confirmLogin();
	 app.logout();
});

test("Test Student Login", function(target, app) {	 
	 app.studentLogin();
	 app.logout();
});

test("Test Student Login", function(target, app) {	 
	 app.taLogin();
	 app.logout();
});

test("Test Student Login", function(target, app) {	 
	 app.teacherLogin();
	 app.logout();
});

test("Verify Login Screenshots", function(target, app) {
	// verify screenshots match
});