#import "../tuneup/tuneup.js"

//var target = UIATarget.localTarget();

test("Conversation is correct", function (target, app) {
	 
	 // Navigate to conversation
	 target.frontMostApp().tabBar().buttons()[2].tap();
	 target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()["iOS Observer, kind of"].tap();
	 
	 //Verify all entries in the conversation
	 assertNotNull(target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].staticTexts()["kind of"]);
	 assertNotNull(target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].links()["Do links work?"]);
	 assertNotNull(target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].staticTexts()["No"]);
	 assertNotNull(target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].staticTexts()["This is how Jason feels about that."]);
	 assertNotNull(target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].staticTexts()["Wha?!?!"]);
	 assertNotNull(target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].staticTexts()["This is just a test. Don't Panic."]);
	 
	 // Scroll the conversation
	 target.frontMostApp().navigationBar().staticTexts()["iOS Observer"].dragInsideWithOptions({startOffset:{x:0.88, y:12.07}, endOffset:{x:0.79, y:1.26}, duration:1.9});
	 
	 // Check to make sure a media attachement works
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].links()["Movie on 1-13-12 at 12.49 PM.mov"].tap();
	 target.frontMostApp().toolbar().buttons()["Done"].tap();
	 
	 // Make sure another media attachement works
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].links()["delete-cookies-monster.jpg"].tap();
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].images()[0].scrollToVisible();
	 target.frontMostApp().toolbar().buttons()["Done"].tap();
	 
	 //Check that the keyboard appears when trying to send a message
	 assertNull(target.frontMostApp().keyboard());
	 target.frontMostApp().toolbar().textFields()[0].tap();
	 assertNotNull(target.frontMostApp().keyboard());
	 
	 // Leave the conversation and come back in
	 target.frontMostApp().navigationBar().leftButton().tap();
	 target.frontMostApp().mainWindow().tableViews()["Empty list"].cells()["iOS Observer, kind of"].tap();
	 
	 
	 // Scroll down and check that a link works
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].staticTexts()[13].scrollToVisible();
	 target.frontMostApp().tabBar().buttons()["Inbox, 1 item"].dragInsideWithOptions({startOffset:{x:0.26, y:-5.38}, endOffset:{x:0.04, y:0.60}, duration:1.8});
	 target.frontMostApp().mainWindow().scrollViews()[0].webViews()[0].links()["Do links work?"].tap();
});
